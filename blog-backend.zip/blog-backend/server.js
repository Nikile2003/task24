const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
const PORT = 5001;

// Middleware
app.use(cors());
app.use(express.json()); // Parse JSON requests

// MySQL Database Connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Nikile2003@",
    database: "blogdb",
});

db.connect((err) => {
    if (err) {
        console.error("Database Connection Failed:", err);
    } else {
        console.log("Connected to MySQL Database ✅");
    }
});

// 🚀 Add a new blog post
app.post("/blogs", (req, res) => {
    const { title, content, author } = req.body;
    if (!title || !content || !author) {
        return res.status(400).json({ error: "All fields are required!" });
    }

    const sql = "INSERT INTO blogs (title, content, author) VALUES (?, ?, ?)";
    db.query(sql, [title, content, author], (err, result) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ error: "Database error occurred" });
        }
        res.json({ message: "Blog added successfully!", blogId: result.insertId });
    });
});

// 📜 Fetch all blog posts
app.get("/blogs", (req, res) => {
    db.query("SELECT * FROM blogs ORDER BY created_at DESC", (err, results) => {
        if (err) {
            console.error("Error fetching blogs:", err);
            return res.status(500).json({ error: "Database error occurred" });
        }
        res.json(results);
    });
});

// 📖 Fetch a single blog by ID
app.get("/blogs/:id", (req, res) => {
    const { id } = req.params;
    db.query("SELECT * FROM blogs WHERE id = ?", [id], (err, result) => {
        if (err) {
            console.error("Error fetching blog:", err);
            return res.status(500).json({ error: "Database error occurred" });
        }
        if (result.length === 0) {
            return res.status(404).json({ error: "Blog not found" });
        }
        res.json(result[0]);
    });
});

// ✏️ Update a blog post
app.put("/blogs/:id", (req, res) => {
    const { id } = req.params;
    const { title, content, author } = req.body;
    if (!title || !content || !author) {
        return res.status(400).json({ error: "All fields are required!" });
    }

    const sql = "UPDATE blogs SET title = ?, content = ?, author = ? WHERE id = ?";
    db.query(sql, [title, content, author, id], (err, result) => {
        if (err) {
            console.error("Error updating blog:", err);
            return res.status(500).json({ error: "Database error occurred" });
        }
        res.json({ message: "Blog updated successfully!" });
    });
});

// 🗑 Delete a blog post
app.delete("/blogs/:id", (req, res) => {
    const { id } = req.params;
    db.query("DELETE FROM blogs WHERE id = ?", [id], (err, result) => {
        if (err) {
            console.error("Error deleting blog:", err);
            return res.status(500).json({ error: "Database error occurred" });
        }
        res.json({ message: "Blog deleted successfully!" });
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
app.delete("/blogs", (req, res) => {
    db.query("DELETE FROM blogs", (err, result) => {
      if (err) {
        return res.status(500).json({ message: "Error deleting all blogs" });
      }
      res.json({ message: "All blogs deleted successfully" });
    });
  });
  
